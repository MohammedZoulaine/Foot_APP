import React from "react";

export default function Settings() {
  return (
    <div className="p-3">
      <h4 className="fw-bold">Paramètres</h4>
      <p>Vous pouvez configurer ici les options globales du système.</p>
    </div>
  );
}