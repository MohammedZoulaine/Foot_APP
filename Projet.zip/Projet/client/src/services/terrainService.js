import api from "./api";

export const getAllTerrains = () => api.get("/terrains");